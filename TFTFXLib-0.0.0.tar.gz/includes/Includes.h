#ifndef INCLUDES_H
#define INCLUDES_H

#include <Arduino.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include "Debug.h"

#endif